var downloadall=(function(){"use strict";function Ie(e){return e}const U=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
  <g stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M6 21H18" />
    <path d="M12 3V17" />
    <path d="M12 17L17 12" />
    <path d="M12 17L7 12" />
  </g>
</svg>`,Y=`<svg width="160" height="160" viewBox="0 0 160 160" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<rect width="160" height="160" fill="url(#pattern0_1_2484)"/>
<defs>
<pattern id="pattern0_1_2484" patternContentUnits="objectBoundingBox" width="1" height="1">
<use xlink:href="#image0_1_2484" transform="scale(0.00625)"/>
</pattern>
<image id="image0_1_2484" width="160" height="160" preserveAspectRatio="none" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAACgCAYAAACLz2ctAAAgAElEQVR4Ae2dCXhV5bX310nISMh4hiSoV2trhcoDaul3awv6VavX1tT2FrVe+/W297b3Xu0Vej+10esU5lEIQxJmEIhlkDlkngdCEiSMAiKzRfBW8GurFWv9f8//3ftNNjFIhn1OTsLez7NyjJycvd/1/+213rX2u/cRCcSWIeHygu8GyfDdIy95ngzJcGe7MtybXBm+SleGd4crw7vTNdbX5MpoY/x/jnXfB+35lT5XvqcG7k3URF70jJaXvN81tJLwQKDhv308G5cgL3nvC3nZM971sqfAleE96Rrr/YtrnA+u8aZN8MI1wQfXxMvYJB9cjnXfB5fzL31PDbQe1Gas92Ol1cueAmpHDYVa9prtxaThQugyPE2usd6LrvGEzAvXRC9ck71wTfHBNdW0aT64tE33waVthg+utqb/zXlt9dMX+aKt//i79f3a73zVelAbakStFJheAnmRWlJTobZBu73ku1syvKtkrPd9Ge+FTPRCJnshU7yQaT7IdB9khg/yig8y0weZlQzJTIbM9kFm89W0OckQx/znA+1n9eozNKAW1ITaUCNqRc2oHTWkltSU2lJjah0024ueWyXDs1zGej+UCTxgHrg5gBkcmAYtGTI3GTIvBZKVAslOgeSkQOa3sQUpkLa2MBXiWOd90NaP/L2tv6kDjZpQG2pEOBkcqB01VDD6DG2pMbWm5tS+x7YMT4y87HlWxnreMcBjpPMaZxDPJg6CkSwruRW0hSmQRSmQJSmQpbRUyLJUyHKrDYS86phffLB84KW+pu+pAbWgJtSGGhFSBgdqRw2pJTVldKTGjIoKRM87ioHfugcElkOSP9ZTKOM9xsEo8LyQWT7IHJ8JXbIRyRabsC1LgbyaClmRClmZAlnpg6z0QFYmQVYmQFbGG7YqAeKY/3yg/Ex/0+h7akAtUgxtqBG1IpTUjlEzxwwk1JYazzCDDUEkA2QhYNEww/0TGec5ruYFUxnxNHjJkGwTOhXlzKhG4HIHQnKTIbluSG4C5Hdu9Ft3DeI23Yxr8m7HVwu/jSHF/xvDSr7jWAB8MKT4Lny14FvK99SAWlATpY3SiFoNNIBkdlqSakRHwkiNGRU1iGSAc0QyQTb8uo31PiPjPR+qEMyox7Cs0ywPjmcMwzqhWzUQ8juaF/K7RMg6Hzxbb8Hw8vvxUOO/47/2vYxxhzIx8+2FmHd8OeafWIWFJ3MdC4AP6Gv6nL6nBtTi4cb/UNpQI2qlNFPaDTS0pKbUVkdFnZ7JgE7LZIOM+GXLcI+VCR6jMmLUy/RC5vmM8MyIx5DN8L0q1QBvjQ+yJgGRm67HbeXfxb80/19MOjIXC0+uwvJ31ipbeno1Fp1+DQtPrcICxwLqg4WnVynfUwOlx+m1ShtqRK2oGbWjhkItGUyoLTWm1tScqZkMkAUywaqZjJAVW7e28LF1kuWDLEg2Jq+vpljAS1EHHbHpOtxR/QCePjAW2SdfxdJ3VoODzjq5DHNPLsEc2qklmHtqqWM96ANqQC2oCbWhRtSKmlE7akgtDRBTLCCahQsZIAtkwi8QjnM/LRM9EOb6V7yQ2V5jHsBqiZNVTl5fS4WsHQhZ64Ws92BQ2QiM3v+iGsTC0yvVAGedXIhWW4RZJxdh1inHgsIH1EJZq0aEktoRRGpJTamt0phaU3NqTwbIAueGZIOMqHkhixP3U90LhBmeUTLR/ZFM9RgfPMcLyfFBFiVDljPqpUBWp0LWpUJeT0T/rdfjwcZ/xoxjOcg59SpmnliA6SdyMP1kDmbQTl3GTudghmOB98Hl9DhpaEbtqCG1pKbUlhpTa6U5tScDZIFMkA0yoiD0QLEz1vNQ1yAc5x0qE9ynWuCba8K3OBnyKqskplqClwJZn4iUoiF4fF+6CuUzT+RgyvG5mHJiLqactNipuZhitdNzMaXF5mHKaccC5wOL762a8L+tmlHD43NBTZmmqTG1lvUJhvZkgCyQCbJBCMlKK4SnhSx1amOTeYKnWKa6ITO9BtXzfcYOuKPXUiBrUyEbUiAbE3Fj+f/Cbw+Nx6yTCzDpeCYmHJ+FCScyMeGkxU5lYkJbO52JCVZr++/O75/3mR0+sfqc/93eZ1q1o5bHZyltqfFvD43Dl8q/obRXDJAFMqEhJCuMhGSHDJElMtXhbXxSukxxX5p2WyIf53smfJsS8ZWKv8ezhydg2ol5yDg2HRnHpyPjhGknZyBD26kZyHCs9/hA68ZXrSe1PTZdaU3Nqb1sSjQCEZnIZZVsiYQ6HZOlCUnPdoy/cb4hMsl9TmZ4zIKjTeTjfG9jKmRTEq4rvx1PHc7AxOOz8PzRyXjh2GS8cHwyXjgxpdVOTsELVjvV5nf9b/z/jgXOB9rv1tf2tLFqSW2PTVZaU3NqTwbIgmKCbFgjYTarY7ZoPFBMka0v3DIkRMZ7XpVpHqO3w/JaFRzmnI+UbxwI2exGYvEg/PuBZ9QZkf72eKQfHY/0Y6Ydn4B0bScmIF3byQlIp+nfndfg8kV7+mgd+ar1pdZvj1fakwGyQCYUGyoSsjBJNtghQ+wTkimyRcYuu03wjJQp7o9kpgcyzwtZ4IMs80FWJUPWpEA2pEI2exFecA1+3PyvePHtyXjqyEt46u2X8NTRl/DUsZcNO/4SnnKs7/lA60utqfmRlxQDZIFMkA3FCFkhM2SHDJElMkW2yFi7G8mc5F4lM9yQ2R7IfC9kCS9SJ0NWs9JNgWxJgeS58Y0d9+OZIxkY89bzGH3kOYx++zmMPvrfhh37b4x2rO/6QOtMzY88pxggC2SCbChGyAqZITtkiCyRKbJFxtqNghPdt8kU9wWZ5YbM80AW+SDLfZDXkiHrUiCbUiBb3fCW34JfvfkbjH7rOTx++Gk8/tYzePzIM3j8bYsdfQaPO9b3fGDVmJpT+8NPKxbIBNkgI4oVMkN2yBBZIlNki4yRtc9tk5ImynQ3ZI4HkuOBLGXq5fXcZKPK2eJDSH4y7tk5Cv956Lf45cEx+OXh3+CXb5l25Df4pWNXjw+07mTg4BjFBNkgI7LFZzBDdsgQWSJTZIuMkbVLtslxCTI1sVlmuiFZjH5eyKtcxeKDvJ4M2Wyk3msqh+Hn+3+NX7z5n/jZwSfws8MWe+sJ/Myxq8cHVu0PPqGYIBtkRKViMkN2yBBZIlNki4yRNTLXsk1OvFemJ30is92Q+Yx+Xsgqr7EKYmMyZKsPrgIfRjalqR09euBXePTgv+HRQ6Yd/jc86tjV5wOtP1k48CvFBhkhK2RGyA5X0pAlMkW2yNj0pL8KmWvZpiSNl1eSjDy90HNp9GPhsc2NxPKb8aM9P8MjB/4Vow78HKMO/sKwQ7/AKMeuXh9oDg78XLFBRsgKmVEFiTUKki3OBckamVPbAgmTaUnFkpkEyfZAlnCJto5+PkheMiTfjUHbv4WH9v0cD+57DA8eoP0UD775Uzx40LGr2gdkgCyQiX2PKUbICplR7GxkHcFuCrsqHoMxskbmyJ5Mj7tBpieekrluyAI3ZJkH8poX8roPsjkZss2L0OJU3NF0P36w959w/76Hcf/+R3D/Acd60gffO/AI/GVdGheZ2PewYoSskBmyoxgiS2SKbJExskbmyJ5MS7xXZiZ+IlluyCI3ZIUbspoNReZxI/rFld+I7+x6EPft+THu2fsj3LPvH3HPfsd60gd3H/gh7jyUZpuNPJSGb7/5fdy1/wf4ble0JRN7f6QYIStkRkVBMkSWyBTZImNkjcyRPZmW9KRkJkJykiBL3JBVHsgaL2SjF5LngxQmIbX6Fnyn+Qe4a3ca7tyThjv3puHOfY71hA/u2peGkfsfwJ17H8AD9Y8greYneKD2EaR1wx6oeRjfq3kIDzX8HD/a938wcv/3O68vmdiTphghK2SG7CiGyBKZIltkjKyRObIn05OyZHYiZH4iZBnvjPJAXvdCNnmNEFrkwQ11t2Pkru/hjub7cMfu+3DHnvtwx17HesYH/4DbDtyFx6p+hZzFOchalIPspdnIXsrXzlvWkmzkLFuA1zetR93OevzH/v/CrXvv7Ly+ZIJsNN+HO3d9TzEjRR6DIbJEpsgWGSNrZG5GwjyRVxI2ypxEyMJEyHK3cXsel15v8ULyPZBiH26q/wa+ueu7GL7rbgxvvhvDd9+N4Xsc6wkfDN07EnfsuhcL8hdjZ3kTDuw+gMP7DuHQvoNdtEM4+fZJfPbB31DwXglu23MXbt19Z+f1JRNkY9fdihUyQ3YUQ2SJTPHWTzJG1sgc2ZOZCRUyLxGyKAmyIgmy2gPZ4IFs9UIKPAgtTcZXd3wDt79xF4btGolhzSMxbLdjPeGDobtH4it7h+PXVU+huXYXLrx/HnZt5z+7gB8e/ilufOM2DNt9Z9c0Jhu7RipWyAzZIUOKJTJFtsgYWSNzZE9mxtVLFgFMNAF0Qza4IVs9kAI3+pWm4Cv1X8eQpm/hazu/ia+98U18bZdjPeGDG5tvxR077sP60g04c/T3+PTTT+3iDzN+Pw8DGwdj8K6/77q+ZGPnNxUrZIbskCHFEplazSKXACZCMUf2ZGZik2QlQJYkGo9qWMN1XR5IngdSaAB4w/ZbcXPjN3BT03DctHM4bnrDsUD74Mtv3I5r3xiC58pexqHGN/GnP/3JNvh2/3kfhjR/G9c23dI9bclG03DFCplRABayH+gxmCJbfBwIWSNzZE8y45skmwDymSxJkLVJxgpXLq0hgGXJuG77EHy58TZ8qfFWfKnpVnxpp2OB9oF311dxV+0DKCkvwbnT5/C3v/3NFgA/+ewT/MuRJxG/44bu60o2Gm9VrJAZskOG1LVhrpomW2SMrJE5sqd+5CRAliZCcjWAbuNSShEB9CG1bhCu2zEE1zbcgmsbb1FnCs8WxwLjg5SmQUhpHISpJa/g2O6j+Oijj2yBjx+y7g+b4W74MpIbb+6+nmSj4RbFCpkhO1JksrTJbQBIxsgamTMAjGuSnHjIsgRILu/3TDQiIK/lFSUhtNwLT+1NSK0fhJQdNyOl4WakNDoWOB8MQv+ma/D9yodRX1WP98+9j8/wmS0AnvvkPdyx9x8QvT0VqY2EvJu6ko0dNytWyAzZIUPqujAjINkiY2SNzGXGMQLGNcl8E8DXEo2bjvlmAlhsAJhUeyO89TfBU/8VeBocC6QPYhv/Dqn1g7GgeDFOHzyFixcv2gIfPyTj1FT0q/OoCGjbmOq/olghMwrAYguAvKGdjBFAMndZADcnGZdRipMQUuZBXO3fIbH+S0iovwEJDY4FygfxDdcjtMGDx8p+ib11e3Dh/AXb4Gv6U7NK6xHbk+3VtP4GxQqZITsMYuqSHJm6PIBxkGXxkNd4t3siZHMiJD9J/bGrzI3+Ndcgtu5aDNh+LQbUOxYYH1yH0AY3rq8einUlr+Pdo2fw10//aguALDx+fPCfITUxiK2/zl5Nt1+rWCEzZMcAMMlgSgGYYLA2P05HwNgmydEAxkPWJUA2JUC2JUKKEuEqS0JkVSqiawciqm4gorY75m8fRG8fiIjtKZDtCXiy+Gm81XjY1rbLqvfWIaw2EWF1XnBfto6nbqBihcyQHTKkWCJTZOs1TvfioZjLjOUcMLZJSCP/Z247AJYmIrzSh4iaZETUJiOizjF/+yC8LhlSH4NbKr6J4rISvGdj2+XMxbMYsusOSHWUgtz2sZCRmmTFjKvUCGKXAEjGyJqKgArAAU0yPxayLA6SGwdZFw/ZFA/ZlgApSoCrNAGhlW70q/GgX61HTVo5cXXMfz4I2Z6AfrUJGFc0CSf2HLe17fLsibGQqn4IqXP7R0MyUuNRzJAdMqRYIlNki4yRNTKXOYARkAAOgCyLNQGMg2yKg2yLhxTFQ0rj4apMhKs6Ca7aJLjqHPOrD2qTINvDMLLsPtRX7bC17dLwxybE1w9U0S/EXzqSEbJSmajYUQyRJTK1zgxyZI3MdRRAqUiAVCVAahIgtY751Qd10Yip8iKnaAHeOfgOPrap7XLxbxeR9ubDkAqB1Cb6T0cyQlbITKkZxK4IYM4XR0AHwECddPGQulCMKn4Me+v24oPzH9hS9fJDVpx7DSHVEary9esJ1FEAyVxLBFQADoDkxkLWxZopOA5SFAcpjYNUxEOq4iE18ZBax/zjgwRIXTiSK2/EmpJ1OHvsXdvaLmcuvovBb9wOqXSZkc+PGpIRskJmyA4Z2mZO68gWGVs2APJ5AGMguQMg6waYAMZCimIhpbGQijhIVRykJg5S65j9PiAQAyC1YXii6Dc40vSWrW2X9OMvGqm3Jtb/+pERskJmyA4Z2mYGNbJFxpbFWAHs3yQ5MZClJoBrB0A2xkLyYiGFsZCSWEh5HKQyDlJtQsidOGavD2pDMKjsNrPt8p5tq11U4VHng1SFGxnM37qREbJCZsgOGSJLZIpsEUCyRuYy+7MKdgDs8ZOpNhqh1f0xtmgCTuw5YVvb5eJnF5F24CFIudh7snwRxF0DsL8ZAWMga2MgGwdA8gZACgeYETAWUhkLqY6FMIw7Zq8PagUjSr+LHTa3XVacy0UII191lL3H+0X6kxGyUm5mTzJElsgU2co1s21Of2sEdADssZOqNhwxVUnILlqA39vYdlGFx85bzbkfp0wBChydBzC6SXKiIUv7Q3L7Q9b2h2yMgeTFQApjICUDIOUDIJUDINUDIDWO2eeDGEitYFTxo9i73d62S/rxF8zU2z+wmpERskJmyA4ZIktkimyRMbJG5jKjOQeMapKcKMjSaEhutAlgf0hef0hhf0hJDKQ8BlIZA6mOMfpINc4rV5J0z1j1hiC54nqz7XLWtrZLwx8bEV/nhVSFmvB191g78fdkhKyQGbJDhsjSRjO4kTGyRubInmRGmgBGQXKjTACjIXnRkMJoSEl/SHl/SGV/SDXPJse67wMKynmZC08UjcaRnfa1XVThsf/HlugXYL3ICFkhM2SHDJGljWZwI2NLo0wAI00As6MgS6Igq6Iga8w3b42GFERDivtDyvpDKvpDqkwIuRPHuueDGsGg0qEoLivGe6fta7usOJuLkMowo+3SExqREbJCZsgOGSJLBJBskTGyRuYY/NQPB8DuwdRZoWvCEVoVgbFF421tu6jCo2moEf06e0x2vb9rAEZClkSaETAKsjEKsjUKUhAFKY6GlEVDKqIhVdGQase67YMawYiS72BHtb2rXdKPPQ8pE0h1ZM/pREbICpkhO2SILJGpNWaWJWvZkdYISAAjHAADcXLVhCKmMh7ZRfNtbbuowqPWDalw9Rx89F+HAIxoC2CECWAkZE0kZGMkZGukGQGjIGVRkIooSFWU0dRkY9OxLviAkYltl0dsbbuowmPfj8zo18PakBGyQmaKzSxKlsgU2VplBrvsCDMCzgpvkqxwyOIIyMoIyOoIyIYIyJYISH4kpCgSUhoJKY+EVEZCqhzrmg8IhiC57FqsKVmLs8fsa7usOLsSIRX9IJX9el4fMkJWyAzZIUNkiUyRLTJG1sgc2VM/HAADIFw4pErwROGTtrZdzlw8g8GNQ4zoFwzBofMAhpkRMByyMhyyOhyyIdyMgBGQoghIaQSkPAJSGQGpcqxLPqhm22WI7W2X9KPPmfCx9RIE2pARskJmyE6+mU3JFNkiY4vDzQgYxgjYHoBhDoB2ilkdgtDKMIwtHGdr20UVHjVJxvVeO4+3O591WQDDvgjAMMjiMMhKvikMsoEAhkPywyFF4ZDScEh5OKSSacSxzvkgTM39RhTfZetqF6Pw+CGkVCBVZuM5GLQhI2SFzJAdMkSWyBTZImNkLSsMKvjJrH5NktUPsrgfZGU/yOp+JoBhkPwwSFEYpDQMUh4GUR12DtaxDvugWhBTEWu0XQ7Zd5ORUXiEQipDgksPMkJWyAzZIUNbzKBGtsgYWSNzZM8B0J8nUz+j7VL0kK1tF6PwuMUy9/PnGDr52Z0GcGZok2SFQBaHQFaEQlaHQtaHQjaHQraFQgpDISWhkLJQSAXPOMc67IMqQXJpKtYU29t2ST/6rJF6Gf2CTQ8yQlbIDNkhQ2SJTJEtMkbWyBzZUz8+B2AIZHMIZFsIpDAEUhICKQuBVHDAjl3ZBzxJXZBKwRMFv8aRnUdsu8mo4f81IL46wbjeq+ALMj3ICFkhM2SHDJGl9SEdAZBvMt/sANi9k61KMKhksNF2ecee1S7q5vK9P4CUSPeOzZ9B5AsBZJY1s21rBHQ1SZYLstgFWeGCrHZB1rsgm12QbS5IoQtS4oKUuYzrjOrM5tndUaOzeIHcZqvi53b0GAL9PkFoRajtbZcVZ1cgpJyZKIjHzmvRZIXMkB0yRJbIFNkiY2SNzM10MQVLk2QJZLFAVghktUDWC2SzQLYJpFCMM46rLNTATaAIVQcsqioa8WXxCC8KR0RxJCJLohBVEqVe+d+dNf5tVAlXXLD90LFj6Mhx2vqeKsGIopG2tl1U4dEw2Jz7Bem4yQN1ISuM0mSHDJElMkW2yBhZI3Nkz68AVgiurb0WS5qWYEneEry8/GU8v/h5017A84s7by8segHjFozHfa/fZ0TVYIOwShBTFoPswhz83sa2S/rR9OCHLxgBDC0LxbMHnwXOQz1sZ9+OfWiubcbuLhr/tqmoCWvWrcXNRYOMKNiFyGxrxNOZwDyOUYWjbG27GIVHvBFZ9L6C9bXTEfAVaZJ5AlkkkFcF8juBvN4mBRebYZU3OHMHnbEyQXRlNPIv5KsH7fD57n/99FN1Aw4fOdtZ47cD/fGPf8SRN97GtK3TEcWFj/rM68xx+eO9lYLkkhRbV7uoKx570yDUwB/HbPdnkhGmYB6vNQWTKbJFxsgamSN76oc/AeQASwTDGofh7CdnbXva0/k/nEdzVTN+su3R4AGwwv62y4p3VyCEbY2unPx2w9WRzwtKAHlQxYIxb42xDUBGzjPHziCvMA+DmIp7OgpWCgYVD0JxeTHes6ntogqPHYONCX1HxA+G9wQlgHRMmSCyIhJ5f8izDcIPP/oQx5qPYVpez6fi0HL72y6q8OgtqVfDH7QA8gB1Kr5oXyp+/w/vt6Zi7YQeeB1RNMLWtosqPPicPa526YHxdHmfXQJwrkAWCmS5QF4TyDqBbBJInkAKBFIkhiM4ueQOumNFfkzFhYMMsbpzfF3425jSGGQX2dd2UYXHnjTD7104nm7p0939kRGeNGSG7JAhskSmyBYZI2tkrqUICSSApYLIcj+lYlbFpWaTuruO7MTfjyqwt+2iCo9SXlPt5sneiTHYBm3QA0inFAuGNQzDWX+k4rxHAxcFKwTJxSm2rnZRhUf9YKON0RMAdXefvQJAHqS/UnFBHgYFMBXbvdol/e10I331xuhHeHsFgDzQEkFkWSTy/scPVbFOxdoh3T2rL/P3bP/Y2XZp+KAB8ZXxRtvlMvu0LVX66/M7DeB0aZI5AllgThBzBbJWIBsFslUg+ZYFCZxccgd2WaFg6I6h/knFWx81iiW7jrXN54SWhmJsgX03GanCY3eacfWgzb5s83cgPpeM6IUIZIcMkSUyRbZYhJA1Mkf21I+eApAHWygYc9gPDWqm4oJBfoNwRKG9bRdVeHARp90neSCgs+6jVwHIAy8WRJb6MRVz6RbTjdVJ3fzvmBJ7V7uowmP74Na5XzePz86xdvqzeh2AdHYvS8V2t11U4cEL9709+lHLXgkgD7qXpGLVdrHx2S6q8OC3CukVR705+vVaAHngrIp7QSq2s+2i7vHoC4WH9aTplRFQD4CpuN6PVbHeTxdf2V9Uj9S1abXLijMrEFLMO8jsnaN2et7WRX+0u58uAzhfIMsEskogawSyQSBbzDX9vKbHFEFHcQf+Mn5+gZ+rYjq7C8cfWmK2Xfba801GZz4+g8EsPOjbLhxP0P4NNSQrHBfvByFDZIlMkS0yRtY+14YJBgApRJEgssSPVbF65HDnRR9RMMLWR+qmH0k3RPL3SR1ouHs9gHRYQQBScSeEiSm2t+2iCo9yfplz50+EoI182p99AkAOIohS8ah8+1a7tFzx6Gupt08ByMH4ORVHF0Ubc68rpMDkQntXu6jCoyjEmCdp0frSa6cj4DRpktnmxHCpQFaaE0Z9czoXFPKaHtOFLkS4k0BYvmDodj9UxdXNeJTXiq80hmLBE/n2PdtFXfGoG2z480r77q3/TkbICpkhO/qmdBYhZIuMsd4gc2RP/QhWADmYfMGYQ364VsybmbYNao2C7QjOa8l2tl1U4UFhAn0itzO2K558Xf2bPgUgnVAoiCz2T1U8fet0XJKKLU4PLQrF2PxxOGFT26Wl8NCPOrHsy28w9MQ++hyAdGIPpOIR+fatdlGFR3Na3069GvY+CSAHtU0w5qB/UvFgnYq5nxJBTKG9bRdVePBZeZwbaaH66muXAMwUSI5AlliekMVHKfBuJi4o1E/J0oUIdxJoKxBEFkUi7z37V1BP32KmYkJRLBi1zb62i7riUTvY8GGgfdYT+yMj+pEcZIcMkSX9ZCwyRtbIXEsR0hsApDO3CYbWDcXZj+28r/g8dvERH5t/oqKTJ9+LNUVrbPsmo/S30g34evLkDSSIfRpADs4fqfj4u9iwbQO+vPHL+Onmn+JQ42FbHqmrCo+yeOOSWyAh6Ml99WkA6Vh/pOIPP8Th/YeRW5yLwpoinDvT/UfqqsJjV9rVk3o19H0eQA5Up2Kb7iv+7LPP8Oc//xnn3z2PC/9zAR9f/Ljbz69RhUeBWXhoca6G104DOFWaZJZAsi1FCJ/jxkcp8G4mLqfRj+jg5JI7CAbbam9VTOI+A59e2P2tpfCg34LBV4E8BjLC69wcO9khQ2SJTPHxvCxCyBqZI3vqR28EMF8QWWhvVdx99IxPSD+cbggQTCdsoCC8agCkQ/PMqtimVGwHgKrwKI03ms6BEj2Y9nNVAcjB+iEVdxVEVXi8kWZEv2CCIpDHclUBSMcGUSpe8fsVCMnnNwRdhSX16u0AAAlESURBVHM/DXmnAZwiTTLT/N4Gfn8DHyKtH8/BtfxcTsMJJVdxcHLJHQSbbRUMrbW3Qd3ZKKgKj5rBxpWjYPNPII+HjFiXYpEh/VgOstX6HSEQsqd+9HYAOegtgjFv2netuLMAqsKDVV+wnqSBgvCqBJDO3dZzVbEqPErijaZzoIQO1v10C0D9XSG9LQVrMbYIhtbYu4L6SpFQ3Vy+M83oeenjuJpfrwQgGTO+pstMwZPMOSC/K0Q/J1rfG8xl+dYVMXoeyJ0Eo/H4Ngc2Fa94ZwVC+JWkwe6bQOlFP3D1lF4JQ4b0PcH6+dBkjdM+sqd+8Je+ACCdnCeIzA9Mg1oVHtWDjegXKIGDfT9XPYAUKECpOP1QutElcKJfa0Z0ADTbAH5OxarwKI43WlTBHpUCeXwOgK0Xw/2Vii8pPAIpbm/YlwOgpUDaLBhabX+DWhUeW0OMyXZvgCKQx9glAF8xv7mGVbB+QhbX8HMtv3VJFqsb7qC3GI93k2DMAfsa1KrwqBrcOvfrLb4I1HHS59alWPp+EP1krNZvSbJUwX0VQDp9qyByWyTyztlzM5MqPNia6m0nowNgD0ZOm1Jxw4UGxBfFGz2uQAna2/bjRMB2QLchFavCoynNSb1XOiEcANsBkE5jKmaDuoup+JLC40oiXM3/3iUAZ5iPTLU+JZVFiL4vhEuy9A3qvdm5mwRDqzpfFavCo9IpPDpUfBJAskJm9P0gZEkXIfrxvGROXYqbKPUy3QKgfkQbbyLhOi6u5+KkW9+cxB30VmN1tlEwZn/nquL0g+mGM/n3vXXsgTpuXQGTGb0WkCxZH81mPB8aQvZkklRcAiDvWuKb+yKAFGGLIDKv46lYFR6F8cYJGCgRe/N+vghAsqUjIIMe2ZOJsvFzAPL2ub4KIMXVqfgKNzO1FB5MJb0ZikAe++UA1LdkWgEkezJR5sk084mV1gcU8evVmYL1kiymYD0PDOSA/LEvOqkDqVgVHltC+s64/eHLtp9JRsgKUzDZIUNkSQNIxoynozIFZ4mMlydlqvm0It4wzAWDXLfFRalcx6WvhnBSqeeBFLC322ZB5NZI5J1tv0GtCo+Kwa1zv94+3kAdPxnRBQjZIUP6a1rJFhnjw7DIHNmT8XKvTJVP1J3qXKmqAWTVYr0c19cApCAbBUMr26+KVeHBSTTP6ECJ1xf20xZAXQEzqOnV0MZTET5R7Ml4uUGmyqmWO+Osq6J1K8ZaCfclQTiWDYLR+0dfsvK+4XwD4gvijTO5L0ARqDFY0y+ZYRvPCiDZ0svxyRzZkwUSJpOkWHg9WK+Kti5I4Ie0nQcGakCB2I+Ziree3aogVIVHY5rRQgjE/vvSPqwAkhkrgGSKAJIxskbmMiRc1DZJxgsbg3PNr1Nv2wvsywASgI2CYZXD8MEnH2D9mfUI2WwWHn0JjkCMpS2ALECsPcAFJmNGE3q8AR9/TpZ7Zbr8teX7QnjzMKsWayXMVgTngdxJIAYTyH1wTJsFj+16DF+v/rpRwQVy/31lX6YfeUJ/rgImU2zBsAIma2SuZZssCTJVmi9biDCUtp0H9kUQ+2KhFQi4yQJNt1/am/9dWoA0C5m7ZJskE1VuZhomqexat42C/GAtEnemd9xXXvvimAKhDf1GIxtkpL3+H5kiW8b8b+Il7KlfJsptMk0uqBDJZqH1OTG6H8gP16nYEavvnYBdhVXDRzbIiLX/p58H09qAviBk7XNbhoTIVFnVkoZZsbBysV4XJtl9PQp2VYSr9e8uF/108aGrX7ZfjP7fKiFr7W5TZKTMkI/Ut1m3TcOMgnou6ERBJ/rpE65t9CMjZMV6+Y0scQUM2SJjl91I5jR5td0oqCtihldGQV7rY87Xc0J9QM7r1QGnBo/666VXZENf+2XmbBv9yNZlo5+mcooMkRlyThGr54K8jKIvzekFCoyCOhJaQdQh2Xk1JuZ90Q9ab75qDnThYb3ywTqCDBnR75yQrQ5tUyVdRUF2rdk81I1pRkGdirlD7rxtJOyLDnfGdOnJpAGk9mSALFhTr158SnbIkDH3S+8Qe+pNGRIj06S4pSJmD6dtQaJTsQPhpeL0dVjbwqerXutVD7JCZlorX152i+k4gHznFBkqM+W06t1wEslwqlOxXqxqLUqcSNj3QWwPPjKg4eM0jYzoqx7s+5EhstSlbZo8JJnyF7WCQadi/Qxp5nruuC2EDoh9D0QreDrtMvJp+MgC1/yRDU7XyArbLmSHDHVrmy7PqFTMhYTsDXIHvELCHWoIrenYScl9C0ArfNSWZk27Gj4yQTbICFnhNd9X5OlusdfyxzNkbIcg1I1qDaETDXsvjFbwrFGPGut2yxfBR2Zs3dqDkCGXeZ9zQlbHTMk8uPZAtMLIwXGyrgfpvPasL9pqQa206YhnBY9aU3Nqr9OuNfLZDp8meaZKxx+2zAm5YIGTTpbdbNHwoHRa5vyAB61hZNjWkVG/6kE6r62C95QvtCYaOOql9bPO9agxtabm1J4M6DnfbPlQyIhft5nyE5ktx1sgZMXDsptzAJ4RGkQdEXnwOipaYdRAcsCO9awPqIU2DR010+DpiEdtqTG1pubUvhW+40I2ArK9IrdKphSqJiN7Pez5cALKM6ItiIyIVhg1kFYo9aCd19aoE0hfUAsNnBU6aqcjngaPGlNr3edjo5kskImAblNlgGTKszJX3lFVD88EnhFtQWS1rKOihpFAaig5b9TtHA7escD4QPudr1oPvlqho3ZtwdNRj5UutScDZKHHtllym8yW5TJXPlSdb05GNYgM05ykMipyzsABWYHk2aWNA3cscD7QftevDBJaH2pFzagdNWRQoabUlhmPWlNzah8022y5W+bIKpkn77dERIZpTlI5AA2jFUgOlGdYW9OOcF5bobDDF239zN+pgRU4K3TUjhoyuzHiUVtqTK2DdsuU4TJHxsscaZRs+VidMRyAjow8k6xQck7R1ugEx+z3QVs/83cd4agJtdGRjpox2lFDaklNqW2v2WZJvMyRe9WBz5MCmScnJUv+ogbFa8scoDbCaTWedY7Z7wOrj/nf2v98pSYELks+VlpRMyOQ3CvUsldvvAF5rtwgc+QemSOjZY5kyxzZJHOlUubJDsmSnZIlTY4F1Ac7le+pAbUwNKE29yqtWm4a9y95/x+YFT9wd0eh8QAAAABJRU5ErkJggg=="/>
</defs>
</svg>`,P=`data:image/svg+xml;utf8,${encodeURIComponent(U)}`,K=`data:image/svg+xml;utf8,${encodeURIComponent(Y)}`,R="cqd-style",q=16,X="150ms cubic-bezier(0.2, 0, 0, 1)";function W(){if(typeof document>"u"||document.getElementById(R))return;const e=document.createElement("style");e.id=R,e.textContent=`
    :root {
      --cqd-transition: ${X};

      /* Spinner */
      --cqd-spinner-border: rgba(255, 255, 255, 0.22);
      --cqd-spinner-top: #ffffff;

      /* =================================================================
       * COLOR PALETTE (Light)
       * ================================================================= */
      --cqd-color-normal: #005DD7;
      --cqd-shadow-normal: 0 8px 22px rgba(0, 93, 215, 0.40);
      --cqd-shadow-normal-strong: 0 12px 28px rgba(0, 93, 215, 0.70);

      --cqd-color-success: #00A82D;
      --cqd-shadow-success: 0 12px 28px rgba(0, 168, 45, 0.40);
      --cqd-shadow-success-strong: 0 12px 28px rgba(0, 168, 45, 0.70);

      --cqd-color-error: #FF4036;
      --cqd-shadow-error: 0 12px 28px rgba(255, 64, 54, 0.40);
      --cqd-shadow-error-strong: 0 12px 28px rgba(255, 64, 54, 0.70);

      --cqd-color-trying: #EC6300;
      --cqd-shadow-trying: 0 12px 28px rgba(236, 99, 0, 0.40);
      --cqd-shadow-trying-strong: 0 12px 28px rgba(236, 99, 0, 0.70);

      --cqd-color-comment: #9B00FF;
      --cqd-color-edited: #007F8D;

      --cqd-shadow-base: 0 0px 10px rgba(15, 23, 42, 0.22);
      --cqd-shadow-hover: 0 10px 24px rgba(15, 23, 42, 0.30);
    }

    /* =================================================================
     * DARK MODE
     * ================================================================= */
    .cqd-theme-dark {
      --cqd-color-normal: #006EFF;
      --cqd-shadow-normal: 0 8px 22px rgba(0, 110, 255, 0.40);
      --cqd-shadow-normal-strong: 0 12px 28px rgba(0, 110, 255, 0.70);

      --cqd-color-success: #07DA3F;
      --cqd-shadow-success: 0 12px 28px rgba(7, 218, 63, 0.40);
      --cqd-shadow-success-strong: 0 12px 28px rgba(7, 218, 63, 0.70);

      --cqd-color-error: #FF4036;
      --cqd-shadow-error: 0 12px 28px rgba(255, 64, 54, 0.40);
      --cqd-shadow-error-strong: 0 12px 28px rgba(255, 64, 54, 0.70);

      --cqd-color-trying: #FF9142;
      --cqd-shadow-trying: 0 12px 28px rgba(255, 145, 66, 0.40);
      --cqd-shadow-trying-strong: 0 12px 28px rgba(255, 145, 66, 0.70);

      --cqd-color-comment: #9B00FF;
      --cqd-color-edited: #00D6EE;

      --cqd-spinner-border: rgba(15, 23, 42, 0.22);
      --cqd-spinner-top: #0f172a;
    }

    div[data-stream-item-id] {
      overflow: visible !important;
      contain: none !important;
      z-index: 1;
    }

    /* ===============================
     * 1. DOWNLOAD BUTTON (Single)
     * =============================== */
    .cqd-download-btn {
      position: absolute;
      top: 50%;
      right: 8px;
      z-index: 5;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 40px;
      width: 40px;
      max-width: calc(100% - 16px);
      padding: 0;
      border: none;
      border-radius: 9999px;
      background-color: var(--cqd-color-normal);
      color: #ffffff;
      box-shadow: var(--cqd-shadow-base);
      cursor: pointer;
      transform: translateY(-50%) scale(1);
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 13px;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      will-change: transform, box-shadow, width, border-radius, padding-inline;
      transition:
        width var(--cqd-transition),
        padding-inline var(--cqd-transition),
        border-radius var(--cqd-transition),
        box-shadow var(--cqd-transition),
        transform var(--cqd-transition),
        background-color var(--cqd-transition);
    }

    .cqd-download-btn:not(.cqd-loading):not(.cqd-trying):not(.cqd-success):not(.cqd-error):hover {
      width: 120px;
      padding-inline: 12px;
      box-shadow: var(--cqd-shadow-hover);
      justify-content: flex-start;
      transform: translateY(-50%) scale(1);
      border-radius: 20px;
    }

    .cqd-download-btn:focus-visible {
      outline: 2px solid #ffffff;
      outline-offset: 2px;
      transform: scale(0.97);
    }

    .cqd-download-btn:active {
      transform: translateY(-50%) scale(0.97);
    }

    .cqd-download-btn .cqd-icon-wrapper {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .cqd-download-icon {
      display: block;
      width: 24px;
      height: 24px;
      background-image: url("${P}");
      background-repeat: no-repeat;
      background-position: center;
      background-size: 24px 24px;
      flex-shrink: 0;
      transform-origin: center;
      transition: width var(--cqd-transition), height var(--cqd-transition);
    }

    .cqd-icon-small {
      width: 16px;
      height: 16px;
      background-size: 16px 16px;
    }

    .cqd-icon-medium {
      width: 24px;
      height: 24px;
      background-size: 24px 24px;
    }

    .cqd-icon-large {
      width: 32px;
      height: 32px;
      background-size: 32px 32px;
    }

    .cqd-download-btn .cqd-label {
      opacity: 0;
      margin-left: 0;
      max-width: 0;
      overflow: hidden;
      transition: opacity var(--cqd-transition), max-width var(--cqd-transition), margin-left var(--cqd-transition);
    }

    .cqd-download-btn:not(.cqd-loading):not(.cqd-trying):not(.cqd-success):not(.cqd-error):hover .cqd-label {
      opacity: 1;
      max-width: 110px;
      margin-left: 4px;
    }

    .cqd-download-btn.cqd-loading,
    .cqd-download-btn.cqd-trying,
    .cqd-download-btn.cqd-success,
    .cqd-download-btn.cqd-error {
      padding-inline: 12px;
      border-radius: 20px;
      justify-content: flex-start;
      box-shadow: var(--cqd-shadow-normal);
      width: 150px;
      transform: translateY(-50%) scale(1);
    }

    .cqd-download-btn.cqd-trying {
      width: 110px;
      background-color: var(--cqd-color-trying);
      box-shadow: var(--cqd-shadow-trying);
    }

    .cqd-download-btn.cqd-loading:hover {
      box-shadow: var(--cqd-shadow-normal-strong);
    }

    .cqd-download-btn.cqd-trying:hover {
      box-shadow: var(--cqd-shadow-trying-strong);
    }

    .cqd-download-btn.cqd-loading .cqd-label,
    .cqd-download-btn.cqd-trying .cqd-label {
      opacity: 1;
      max-width: 110px;
      margin-left: 12px;
    }

    .cqd-download-btn.cqd-success {
      width: 140px;
      background-color: var(--cqd-color-success);
      box-shadow: var(--cqd-shadow-success);
    }

    .cqd-download-btn.cqd-success:hover {
      box-shadow: var(--cqd-shadow-success-strong);
    }

    .cqd-download-btn.cqd-success .cqd-label {
      opacity: 1;
      max-width: 110px;
      margin-left: 8px;
    }

    .cqd-download-btn.cqd-error {
      width: auto;
      min-width: 90px;
      background-color: var(--cqd-color-error);
      box-shadow: var(--cqd-shadow-error);
      height: 40px;
      max-width: 150px;
      max-height: 40px;
      padding: 0 12px;
      padding-top: 0;
      padding-bottom: 0;
      align-items: center;
      transition: all var(--cqd-transition);
    }

    .cqd-error-detail {
      display: block;
      font-size: 11px;
      font-weight: 500;
      line-height: 1.3;
      margin: 0;
      opacity: 0;
      max-height: 0;
      overflow: hidden;
      white-space: normal;
      transform: translateY(4px);
      transition: all var(--cqd-transition);
    }

    .cqd-download-btn.cqd-error:hover {
      width: 350px;
      max-width: 360px;
      height: 60px;
      max-height: 61px;
      padding: 8px;
      border-radius: 18px;
      align-items: center;
      gap: 7px;
      box-shadow: var(--cqd-shadow-error-strong);
    }

    .cqd-download-btn.cqd-error:hover .cqd-label {
      opacity: 0;
      max-width: 0;
      margin: 0;
    }

    .cqd-download-btn.cqd-error:hover .cqd-error-detail {
      opacity: 1;
      max-height: 60px;
      margin-top: 4px;
      transform: translateY(0);
    }

    .cqd-spinner {
      background-image: none;
      border-radius: 9999px;
      width: ${q}px;
      height: ${q}px;
      border: 3px solid var(--cqd-spinner-border);
      border-top-color: var(--cqd-spinner-top);
      animation: cqd-spin 0.65s linear infinite;
    }

    @keyframes cqd-spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    /* ===============================
     * 2. COMMENTS & EDITED (Overlay)
     * =============================== */
    .cqd-overlay-container {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      pointer-events: none;
      z-index: 10;
      box-sizing: border-box;
      border-radius: inherit;
      box-shadow:
        inset 0 0 0 2px var(--cqd-color-comment),
        0 0 12px rgba(99, 102, 241, 0.5);
    }

    /* EDITED OVERLAY (Green/Teal) */
    .cqd-overlay-container.cqd-edited {
      box-shadow:
        inset 0 0 0 2px var(--cqd-color-edited),
        0 0 12px rgba(0, 214, 238, 0.3);
    }

    /* BOTH OVERLAY (Red) - Direct Class */
    .cqd-overlay-container.cqd-both {
      box-shadow:
        inset 0 0 0 2px #FF4036,
        0 0 12px rgba(255, 64, 54, 0.70);
    }

    .cqd-comment-badge {
      position: absolute;
      top: 7px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      width: 30px;
      height: 30px;
      background-color: var(--cqd-color-comment);
      color: #ffffff;
      border-radius: 9999px;
      cursor: pointer;
      overflow: hidden;
      transition: height var(--cqd-transition), box-shadow 0.2s ease;
    }

    .cqd-comment-badge:hover {
      height: 50px;
      border-radius: 20px;
      padding-bottom: 8px;
      z-index: 10000;
    }

    body[data-cqd-dir="ltr"] .cqd-comment-badge {
      left: 0;
      transform: translateX(-50%);
    }

    body[data-cqd-dir="rtl"] .cqd-comment-badge {
      right: 0;
      transform: translateX(50%);
    }

    .cqd-badge-icon {
      flex-shrink: 0;
      width: 20px;
      height: 20px;
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
      filter: brightness(0) invert(1);
      margin-top: 4px;
    }

    .cqd-badge-label {
      display: block;
      font-family: system-ui, sans-serif;
      font-size: 13px;
      font-weight: 700;
      opacity: 0;
      transform: translateY(-5px);
      max-height: 0;
      margin-top: 2px;
      overflow: hidden;
      transition: opacity 0.15s ease 0.05s, transform 0.15s ease 0.05s;
    }

    .cqd-comment-badge:hover .cqd-badge-label {
      opacity: 1;
      transform: translateY(0);
      max-height: 20px;
    }

    .cqd-edited-badge {
      position: absolute;
      top: 7px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      width: 30px;
      height: 30px;
      background-color: var(--cqd-color-edited);
      color: #ffffff;
      border-radius: 9999px;
      cursor: default;
      overflow: hidden;
      transition: height var(--cqd-transition), box-shadow 0.2s ease;
      left: 0;
      transform: translateX(-50%);
    }

    body[data-cqd-dir="rtl"] .cqd-edited-badge {
      right: 0;
      transform: translateX(50%);
    }

    body[data-cqd-dir="ltr"] .cqd-edited-badge {
      left: 0;
      transform: translateX(-50%);
    }

    .cqd-edited-icon {
      flex-shrink: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .cqd-edited-icon svg {
      width: 18px;
      height: 18px;
      stroke: currentColor;
    }

    .cqd-edited-badge:hover {
      height: 50px;
      border-radius: 20px;
      padding-bottom: 8px;
      z-index: 10000;
    }

    .cqd-edited-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      opacity: 0;
      transform: translateY(-10px);
      transition: opacity 0.15s ease 0.05s, transform 0.15s ease 0.05s;
      font-family: system-ui, -apple-system, sans-serif;
      font-weight: 700;
      font-size: 13px;
    }

    .cqd-edited-badge:hover .cqd-edited-content {
      opacity: 1;
      transform: translateY(0);
      max-height: 20px;
    }

    .cqd-diff-val {
      font-family: system-ui, -apple-system, sans-serif;
      font-weight: 700;
      font-size: 13px;
    }

    .cqd-both-badge {
      position: absolute;
      top: 7px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      width: 30px;
      height: 70px;
      background-color: #FF4036;
      color: #ffffff;
      border-radius: 9999px;
      border: 1px solid rgba(255, 64, 54, 0.70);
      cursor: pointer;
      overflow: hidden;
      padding-top: 8px;
      transition: height var(--cqd-transition), box-shadow 0.2s ease;
    }

    body[data-cqd-dir="ltr"] .cqd-both-badge {
      left: 0;
      transform: translateX(-50%);
    }

    body[data-cqd-dir="rtl"] .cqd-both-badge {
      right: 0;
      transform: translateX(50%);
    }

    .cqd-both-section {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .cqd-both-icon {
      width: 20px;
      height: 20px;
      background-size: contain;
      background-repeat: no-repeat;
      background-position: center;
    }

    .cqd-both-icon-edited svg {
      width: 18px;
      height: 18px;
      stroke: currentColor;
    }

    .cqd-both-plus {
      font-size: 14px;
      font-weight: 700;
      line-height: 1;
      margin: 5px;
    }

    .cqd-both-value,
    .cqd-both-divider {
      opacity: 0;
      max-height: 0;
      margin-top: 0;
      overflow: hidden;
      transition:
        opacity 0.15s ease 0.05s,
        max-height 0.15s ease 0.05s,
        margin-top 0.15s ease 0.05s;
    }

    .cqd-both-value {
      font-family: system-ui, -apple-system, sans-serif;
      font-size: 11px;
      font-weight: 700;
      text-align: center;
    }

    .cqd-both-badge:hover {
      height: 120px;
      border-radius: 20px;
    }

    .cqd-both-badge:hover .cqd-both-value {
      opacity: 1;
      max-height: 20px;
      margin-top: 2px;
    }

    .cqd-both-badge:hover .cqd-both-divider {
      opacity: 1;
      max-height: 4px;
      margin-top: 2px;
    }

    /* ===============================
     * 1b. DOWNLOAD ALL BUTTON (Header-aligned)
     * =============================== */
    .cqd-download-all-btn {
      /* Progress control (0% to 100%) */
      --cqd-progress: 0%;
      position: absolute;
      top: 12px;
      right: 48px;
      height: 40px;
      z-index: 6;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 4px 12px;
      border: none;
      border-radius: 9999px;
      background-color: var(--cqd-color-normal);
      color: #ffffff;
      box-shadow: var(--cqd-shadow-normal);
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      gap: 6px;
      white-space: nowrap;
      overflow: hidden;
      transition:
        box-shadow 0.2s ease,
        transform 0.1s ease,
        background-color 0.3s ease,
        padding-inline 0.2s ease;
      transform: translateZ(0);
    }

    /* When injected into the header flex structure */
    .cqd-download-all-btn.cqd-in-header {
      position: relative;
      top: auto;
      right: auto;
      left: auto;
      bottom: auto;
      transform: none;
      margin-inline-end: 8px;
      flex-shrink: 0;
      align-self: center;
    }

    /* RTL fallback only for non-header cases (absolute positioned at top corner) */
    body[data-cqd-dir="rtl"] .cqd-download-all-btn:not(.cqd-in-header) {
      right: auto;
      left: 48px;
    }

    .cqd-download-all-btn:hover {
      box-shadow: var(--cqd-shadow-normal-strong);
    }

    .cqd-download-all-btn:active {
      transform: scale(0.97);
    }

    /* Keep pointer cursor even while disabled */
    .cqd-download-all-btn[disabled] {
      cursor: pointer;
    }

    /* FULL SUCCESS STATE (Solid Green) */
    .cqd-download-all-btn.cqd-all-success {
      background-color: var(--cqd-color-success);
      box-shadow: var(--cqd-shadow-success);
    }

    .cqd-download-all-btn.cqd-all-error {
      background-color: var(--cqd-color-error);
      box-shadow: var(--cqd-shadow-error);
    }

    /* PROGRESS BAR OVERLAY (Fills up) */
    .cqd-download-all-btn::after {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      z-index: 0;
      background-color: var(--cqd-color-success);
      /* Width controlled by JS */
      width: var(--cqd-progress);
      transition: width 0.3s cubic-bezier(0.22, 0.61, 0.36, 1);
      opacity: 1;
    }

    .cqd-download-all-btn.cqd-all-success::after {
      opacity: 0;
    }

    /* Content layers */
    .cqd-download-all-btn .cqd-download-all-main,
    .cqd-download-all-btn .cqd-download-all-sub,
    .cqd-download-all-btn .cqd-download-all-icon-wrapper {
      position: relative;
      z-index: 2;
    }

    .cqd-download-all-btn .cqd-download-all-icon-wrapper {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .cqd-download-all-btn .cqd-download-all-icon {
      width: 18px;
      height: 18px;
      background-image: url("${P}");
      background-repeat: no-repeat;
      background-position: center;
      background-size: 18px 18px;
      flex-shrink: 0;
    }

    /* Swap icon on success */
    .cqd-download-all-btn.cqd-all-success .cqd-download-all-icon {
      background-image: url("${K}");
    }

    /* Spinner when disabled (Loading) but not success/error */
    .cqd-download-all-btn[disabled]:not(.cqd-all-success):not(.cqd-all-error) .cqd-download-all-icon {
      background-image: none;
      border-radius: 9999px;
      width: ${q}px;
      height: ${q}px;
      border: 3px solid var(--cqd-spinner-border);
      border-top-color: var(--cqd-spinner-top);
      animation: cqd-spin 0.65s linear infinite;
    }

    .cqd-download-all-btn .cqd-download-all-main {
      font-weight: 600;
    }

    /* Download All Sub-Text Behavior (Hover & Active) */
    .cqd-download-all-btn .cqd-download-all-sub {
      font-size: 11px;
      opacity: 0;
      max-width: 0;
      margin-left: 0;
      overflow: hidden;
      white-space: nowrap;
      transition: 
        opacity 0.2s ease, 
        max-width 0.2s ease, 
        margin-left 0.2s ease;
    }

    /* Hover State: Reveal sub-text */
    .cqd-download-all-btn:not([disabled]):hover .cqd-download-all-sub {
      opacity: 0.9;
      max-width: 100px;
      margin-left: 4px;
    }

    /* Active/Disabled State: Always show sub-text (progress) */
    .cqd-download-all-btn[disabled] .cqd-download-all-sub {
      opacity: 0.9;
      max-width: 100px;
      margin-left: 4px;
    }
  `.trim(),(document.head||document.documentElement).appendChild(e)}const c={en:{download:"Download",downloading:"Downloading…",trying:"Trying…",downloaded:"Downloaded",error:"Error",failed:"Download failed.",ariaDownload:"Download",titleQuick:"Quick download",comments:"comments",edited:"Edited",downloadAll:"Download all"},ar:{download:"تنزيل",downloading:"جاري التنزيل…",trying:"محاولة…",downloaded:"تم التنزيل",error:"خطأ",failed:"فشل التنزيل.",ariaDownload:"تنزيل",titleQuick:"تنزيل سريع",comments:"تعليقات",edited:"تم التعديل",downloadAll:"تنزيل الكل"},ja:{download:"ダウンロード",downloading:"DL中…",trying:"試行中…",downloaded:"完了",error:"エラー",failed:"失敗しました。",ariaDownload:"ダウンロード",titleQuick:"クイックダウンロード",comments:"件のコメント",edited:"編集済み"},es:{download:"Descargar",downloading:"Descargando…",trying:"Intentando…",downloaded:"Descargado",error:"Error",failed:"Falló la descarga.",ariaDownload:"Descargar",titleQuick:"Descarga rápida",comments:"comentarios",edited:"Editado"},hi:{download:"डाउनलोड",downloading:"डाउनलोडिंग…",trying:"कोशिश जारी…",downloaded:"पूर्ण",error:"त्रुटि",failed:"विफल रहा",ariaDownload:"डाउनलोड",titleQuick:"त्वरित डाउनलोड",comments:"टिप्पणियाँ",edited:"संपादित"},pt:{download:"Baixar",downloading:"Baixando…",trying:"Tentando…",downloaded:"Baixado",error:"Erro",failed:"Falha ao baixar.",ariaDownload:"Baixar",titleQuick:"Download rápido",comments:"comentários",edited:"Editado"},"pt-pt":{download:"Descarregar",downloading:"A descarregar…",trying:"A tentar…",downloaded:"Descarregado",error:"Erro",failed:"Falha ao descarregar.",ariaDownload:"Descarregar",titleQuick:"Descarga rápida",comments:"comentários",edited:"Editado"},"zh-cn":{download:"下载",downloading:"下载中…",trying:"尝试中…",downloaded:"已下载",error:"错误",failed:"下载失败",ariaDownload:"下载",titleQuick:"快速下载",comments:"条评论",edited:"已编辑"},"zh-tw":{download:"下載",downloading:"下載中…",trying:"嘗試中…",downloaded:"已下載",error:"錯誤",failed:"下載失敗",ariaDownload:"下載",titleQuick:"快速下載",comments:"則留言",edited:"已編輯"},fr:{download:"Télécharger",downloading:"Téléchargement…",trying:"Essai…",downloaded:"Téléchargé",error:"Erreur",failed:"Échec.",ariaDownload:"Télécharger",titleQuick:"Téléchargement rapide",comments:"commentaires",edited:"Modifié"},de:{download:"Herunterladen",downloading:"Laden…",trying:"Versuchen…",downloaded:"Fertig",error:"Fehler",failed:"Fehlgeschlagen.",ariaDownload:"Herunterladen",titleQuick:"Schneller Download",comments:"Kommentare",edited:"Bearbeitet"},it:{download:"Scarica",downloading:"Scaricamento…",trying:"Provando…",downloaded:"Scaricato",error:"Errore",failed:"Fallito.",ariaDownload:"Scarica",titleQuick:"Download rapido",comments:"commenti",edited:"Modificato"},ru:{download:"Скачать",downloading:"Скачивание…",trying:"Попытка…",downloaded:"Скачано",error:"Ошибка",failed:"Сбой.",ariaDownload:"Скачать",titleQuick:"Быстрое скачивание",comments:"комментариев",edited:"Изменено"},ko:{download:"다운로드",downloading:"다운로드 중…",trying:"시도 중…",downloaded:"완료",error:"오류",failed:"실패함",ariaDownload:"다운로드",titleQuick:"빠른 다운로드",comments:"개 댓글",edited:"수정됨"},tr:{download:"İndir",downloading:"İndiriliyor…",trying:"Deneniyor…",downloaded:"İndirildi",error:"Hata",failed:"Başarısız.",ariaDownload:"İndir",titleQuick:"Hızlı indir",comments:"yorum",edited:"Düzenlendi"},vi:{download:"Tải xuống",downloading:"Đang tải…",trying:"Đang thử…",downloaded:"Đã tải",error:"Lỗi",failed:"Thất bại.",ariaDownload:"Tải xuống",titleQuick:"Tải xuống nhanh",comments:"nhận xét",edited:"Đã chỉnh sửa"},id:{download:"Download",downloading:"Mengunduh…",trying:"Mencoba…",downloaded:"Selesai",error:"Kesalahan",failed:"Gagal.",ariaDownload:"Download",titleQuick:"Download cepat",comments:"komentar",edited:"Diedit"},th:{download:"ดาวน์โหลด",downloading:"กำลังโหลด…",trying:"พยายาม…",downloaded:"เสร็จสิ้น",error:"ข้อผิดพลาด",failed:"ล้มเหลว",ariaDownload:"ดาวน์โหลด",titleQuick:"ดาวน์โหลดด่วน",comments:"ความคิดเห็น",edited:"แก้ไขแล้ว"},pl:{download:"Pobierz",downloading:"Pobieranie…",trying:"Próba…",downloaded:"Pobrano",error:"Błąd",failed:"Nieudane.",ariaDownload:"Pobierz",titleQuick:"Szybkie pobieranie",comments:"komentarze",edited:"Edytowano"},nl:{download:"Downloaden",downloading:"Downloaden…",trying:"Proberen…",downloaded:"Klaar",error:"Fout",failed:"Mislukt.",ariaDownload:"Downloaden",titleQuick:"Snel downloaden",comments:"reacties",edited:"Bewerkt"},bn:{download:"ডাউনলোড",downloading:"ডাউনলোড হচ্ছে…",trying:"চেষ্টা করছে…",downloaded:"সম্পন্ন",error:"ত্রুটি",failed:"ব্যর্থ হয়েছে",ariaDownload:"ডাউনলোড",titleQuick:"দ্রুত ডাউনলোড",comments:"টি মন্তব্য",edited:"সম্পাদিত"},pa:{download:"ਡਾਉਨਲੋਡ",downloading:"ਡਾਉਨਲੋਡ ਹੋ ਰਿਹਾ…",trying:"ਕੋਸ਼ਿਸ਼ ਜਾਰੀ…",downloaded:"ਮੁਕੰਮਲ",error:"ਗਲਤੀ",failed:"ਅਸਫਲ",ariaDownload:"ਡਾਉਨਲੋਡ",titleQuick:"ਤੇਜ਼ ਡਾਉਨਲੋਡ",comments:"ਟਿੱਪਣੀਆਂ",edited:"ਸੰਪਾਦਿਤ"},te:{download:"డౌన్‌లోడ్",downloading:"డౌన్‌లోడ్ అవుతోంది…",trying:"ప్రయత్నిస్తోంది…",downloaded:"పూర్తయింది",error:"లోపం",failed:"విఫలమైంది",ariaDownload:"డౌన్‌లోడ్",titleQuick:"త్వరిత డౌన్‌లోడ్",comments:"వ్యాఖ్యలు",edited:"సవరించబడింది"},mr:{download:"डाउनलोड",downloading:"डाउनलोड होत आहे…",trying:"प्रयत्न करत आहे…",downloaded:"पूर्ण",error:"त्रुटी",failed:"अयशस्वी",ariaDownload:"डाउनलोड",titleQuick:"त्वरित डाउनलोड",comments:"टिप्पण्या",edited:"संपादित"},ta:{download:"பதிவிறக்கு",downloading:"பதிவிறக்கப்படுகிறது…",trying:"முயற்சிக்கிறது…",downloaded:"முடிந்தது",error:"பிழை",failed:"தோல்வி",ariaDownload:"பதிவிறக்கு",titleQuick:"விரைவு பதிவிறக்கம்",comments:"கருத்துகள்",edited:"திருத்தப்பட்டது"},ur:{download:"ڈاؤن لوڈ",downloading:"ڈاؤن لوڈ ہو رہا ہے…",trying:"کوشش جاری…",downloaded:"مکمل",error:"غلطی",failed:"ناکام",ariaDownload:"ڈاؤن لوڈ",titleQuick:"فوری ڈاؤن لوڈ",comments:"تبصرے",edited:"ترمیم شدہ"},gu:{download:"ડાઉનલોડ",downloading:"ડાઉનલોડ થઈ રહ્યું છે…",trying:"પ્રયાસ ચાલુ…",downloaded:"પૂર્ણ",error:"ભૂલ",failed:"નિષ્ફળ",ariaDownload:"ડાઉનલોડ",titleQuick:"ઝડપી ડાઉનલોડ",comments:"ટિપ્પણીઓ",edited:"સંપાદિત"},kn:{download:"ಡೌನ್‌ಲೋಡ್",downloading:"ಡೌನ್‌ಲೋಡ್ ಆಗುತ್ತಿದೆ…",trying:"ಪ್ರಯತ್ನಿಸುತ್ತಿದೆ…",downloaded:"ಪೂರ್ಣಗೊಂಡಿದೆ",error:"ದೋಷ",failed:"ವಿಫಲವಾಗಿದೆ",ariaDownload:"ಡೌನ್‌ಲೋಡ್",titleQuick:"ತ್ವರಿತ ಡೌನ್‌ಲೋಡ್",comments:"ಕಾಮೆಂಟ್‌ಗಳು",edited:"ಸಂಪಾದಿಸಲಾಗಿದೆ"},ml:{download:"ഡൗൺലോഡ്",downloading:"ഡൗൺലോഡ് ചെയ്യുന്നു…",trying:"ശ്രമിക്കുന്നു…",downloaded:"പൂർത്തിയായി",error:"പിശക്",failed:"പരാജയപ്പെട്ടു",ariaDownload:"ഡൗൺലോഡ്",titleQuick:"വേഗത്തിൽ ഡൗൺലോഡ്",comments:"അഭിപ്രായങ്ങൾ",edited:"എഡിറ്റുചെയ്തു"},uk:{download:"Завантажити",downloading:"Завантаження…",trying:"Спроба…",downloaded:"Готово",error:"Помилка",failed:"Невдача.",ariaDownload:"Завантажити",titleQuick:"Швидке завантаження",comments:"коментарів",edited:"Змінено"},el:{download:"Λήψη",downloading:"Λήψη…",trying:"Προσπάθεια…",downloaded:"Ολοκληρώθηκε",error:"Σφάλμα",failed:"Απέτυχε.",ariaDownload:"Λήψη",titleQuick:"Γρήγορη λήψη",comments:"σχόλια",edited:"Επεξεργασμένο"},cs:{download:"Stáhnout",downloading:"Stahování…",trying:"Zkouším…",downloaded:"Staženo",error:"Chyba",failed:"Selhalo.",ariaDownload:"Stáhnout",titleQuick:"Rychlé stažení",comments:"komentářů",edited:"Upraveno"},ro:{download:"Descărcați",downloading:"Se descarcă…",trying:"Se încearcă…",downloaded:"Finalizat",error:"Eroare",failed:"Eșuat.",ariaDownload:"Descărcați",titleQuick:"Descărcare rapidă",comments:"comentarii",edited:"Modificat"},hu:{download:"Letöltés",downloading:"Letöltés…",trying:"Próbálkozás…",downloaded:"Kész",error:"Hiba",failed:"Sikertelen.",ariaDownload:"Letöltés",titleQuick:"Gyors letöltés",comments:"megjegyzés",edited:"Szerkesztve"},sv:{download:"Ladda ner",downloading:"Laddar ner…",trying:"Försöker…",downloaded:"Klart",error:"Fel",failed:"Misslyckades.",ariaDownload:"Ladda ner",titleQuick:"Snabb nedladdning",comments:"kommentarer",edited:"Redigerad"},da:{download:"Hent",downloading:"Henter…",trying:"Prøver…",downloaded:"Hentet",error:"Fejl",failed:"Mislykkedes.",ariaDownload:"Hent",titleQuick:"Hurtig download",comments:"kommentarer",edited:"Redigeret"},fi:{download:"Lataa",downloading:"Ladataan…",trying:"Yritetään…",downloaded:"Ladattu",error:"Virhe",failed:"Epäonnistui.",ariaDownload:"Lataa",titleQuick:"Pikalataus",comments:"kommenttia",edited:"Muokattu"},no:{download:"Last ned",downloading:"Laster ned…",trying:"Prøver…",downloaded:"Ferdig",error:"Feil",failed:"Mislyktes.",ariaDownload:"Last ned",titleQuick:"Rask nedlasting",comments:"kommentarer",edited:"Redigert"},he:{download:"הורדה",downloading:"מוריד…",trying:"מנסה…",downloaded:"הושלם",error:"שגיאה",failed:"נכשל",ariaDownload:"הורדה",titleQuick:"הורדה מהירה",comments:"תגובות",edited:"נערך"},fa:{download:"دانلود",downloading:"درحال دانلود…",trying:"تلاش مجدد…",downloaded:"انجام شد",error:"خطا",failed:"ناموفق",ariaDownload:"دانلود",titleQuick:"دانلود سریع",comments:"نظر",edited:"ویرایش شده"},fil:{download:"I-download",downloading:"Nagda-download…",trying:"Sinusubukan…",downloaded:"Tapos na",error:"Error",failed:"Nabigo.",ariaDownload:"I-download",titleQuick:"Mabilis na download",comments:"mga komento",edited:"Na-edit"},ms:{download:"Muat turun",downloading:"Memuat turun…",trying:"Mencuba…",downloaded:"Selesai",error:"Ralat",failed:"Gagal.",ariaDownload:"Muat turun",titleQuick:"Muat turun pantas",comments:"komen",edited:"Diedit"},sr:{download:"Преузми",downloading:"Преузимање…",trying:"Покушавам…",downloaded:"Завршено",error:"Грешка",failed:"Неуспешно.",ariaDownload:"Преузми",titleQuick:"Брзо преузимање",comments:"коментара",edited:"Измењено"},sk:{download:"Stiahnuť",downloading:"Sťahovanie…",trying:"Skúšam…",downloaded:"Hotovo",error:"Chyba",failed:"Zlyhalo.",ariaDownload:"Stiahnuť",titleQuick:"Rýchle stiahnutie",comments:"komentárov",edited:"Upravené"},bg:{download:"Изтегли",downloading:"Изтегляне…",trying:"Опит…",downloaded:"Готово",error:"Грешка",failed:"Неуспешно.",ariaDownload:"Изтегли",titleQuick:"Бързо изтегляне",comments:"коментара",edited:"Редактирано"},hr:{download:"Preuzmi",downloading:"Preuzimanje…",trying:"Pokušavam…",downloaded:"Gotovo",error:"Greška",failed:"Neuspjelo.",ariaDownload:"Preuzmi",titleQuick:"Brzo preuzimanje",comments:"komentara",edited:"Uređeno"},lt:{download:"Atsisiųsti",downloading:"Siunčiama…",trying:"Bandoma…",downloaded:"Baigta",error:"Klaida",failed:"Nepavyko.",ariaDownload:"Atsisiųsti",titleQuick:"Greitas atsisiuntimas",comments:"komentarai",edited:"Redaguota"},lv:{download:"Lejupielādēt",downloading:"Lejupielādē…",trying:"Mēģina…",downloaded:"Pabeigts",error:"Kļūda",failed:"Neizdevās.",ariaDownload:"Lejupielādēt",titleQuick:"Ātrā lejupielāde",comments:"komentāri",edited:"Rediģēts"},et:{download:"Laadi alla",downloading:"Laadimine…",trying:"Proovin…",downloaded:"Valmis",error:"Viga",failed:"Ebaõnnestus.",ariaDownload:"Laadi alla",titleQuick:"Kiire allalaadimine",comments:"kommentaari",edited:"Muudetud"},sl:{download:"Prenos",downloading:"Prenašanje…",trying:"Poskušam…",downloaded:"Končano",error:"Napaka",failed:"Ni uspelo.",ariaDownload:"Prenos",titleQuick:"Hiter prenos",comments:"komentarjev",edited:"Urejeno"},ca:{download:"Descarrega",downloading:"Descarregant…",trying:"Intentant…",downloaded:"Descarregat",error:"Error",failed:"Ha fallat.",ariaDownload:"Descarrega",titleQuick:"Descàrrega ràpida",comments:"comentaris",edited:"Editat"},af:{download:"Aflaai",downloading:"Laai af…",trying:"Probeer…",downloaded:"Klaar",error:"Fout",failed:"Misluk.",ariaDownload:"Aflaai",titleQuick:"Vinnige aflaai",comments:"kommentare",edited:"Geredigeer"},am:{download:"አውርድ",downloading:"በማውረድ ላይ…",trying:"በመሞከር ላይ…",downloaded:"ወርዷል",error:"ስህተት",failed:"አልተሳካም።",ariaDownload:"አውርድ",titleQuick:"ፈጣን ማውረድ",comments:"አስተያየቶች",edited:"ተስተካክሏል"},hy:{download:"Ներբեռնել",downloading:"Ներբեռնում…",trying:"Փորձում է…",downloaded:"Ավարտված",error:"Սխալ",failed:"Ձախողվեց:",ariaDownload:"Ներբեռնել",titleQuick:"Արագ ներբեռնում",comments:"մեկնաբանություն",edited:"Խմբագրվել է"},as:{download:"ডাউন্লোড",downloading:"ডাউন্লোড হৈ আছে…",trying:"চেষ্টা কৰি আছে…",downloaded:"সম্পূৰ্ণ",error:"ত্ৰুটি",failed:"বিফল হ’ল",ariaDownload:"ডাউন্লোড",titleQuick:"দ্ৰুত ডাউন্লোড",comments:"মন্তব্য",edited:"সম্পাদিত"},az:{download:"Yüklə",downloading:"Yüklənir…",trying:"Cəhd edilir…",downloaded:"Bitdi",error:"Xəta",failed:"Alınmadı.",ariaDownload:"Yüklə",titleQuick:"Sürətli yükləmə",comments:"şərh",edited:"Düzəliş edilib"},eu:{download:"Deskargatu",downloading:"Deskargatzen…",trying:"Saiatzen…",downloaded:"Eginda",error:"Errorea",failed:"Huts egin du.",ariaDownload:"Deskargatu",titleQuick:"Deskarga azkarra",comments:"iruzkin",edited:"Editatua"},my:{download:"ဒေါင်းလုဒ်",downloading:"ဒေါင်းလုဒ် လုပ်နေ…",trying:"ကြိုးစားနေ…",downloaded:"ပြီးပါပြီ",error:"အမှား",failed:"မအောင်မြင်ပါ။",ariaDownload:"ဒေါင်းလုဒ်",titleQuick:"အမြန် ဒေါင်းလုဒ်",comments:"မှတ်ချက်များ",edited:"ပြင်ဆင်ပြီး"},gl:{download:"Descargar",downloading:"Descargando…",trying:"Tentando…",downloaded:"Descargado",error:"Erro",failed:"Fallou.",ariaDownload:"Descargar",titleQuick:"Descarga rápida",comments:"comentarios",edited:"Editado"},ka:{download:"ჩამოტვირთვა",downloading:"იწერება…",trying:"მცდელობა…",downloaded:"დასრულდა",error:"შეცდომა",failed:"ვერ მოხერხდა.",ariaDownload:"ჩამოტვირთვა",titleQuick:"სწრაფი ჩამოტვირთვა",comments:"კომენტარი",edited:"რედაქტირებულია"},is:{download:"Sækja",downloading:"Sækir…",trying:"Reyni…",downloaded:"Sótt",error:"Villa",failed:"Mistókst.",ariaDownload:"Sækja",titleQuick:"Flýtiniðurhal",comments:"ummæli",edited:"Breytt"},ga:{download:"Íoslódáil",downloading:"Ag íoslódáil…",trying:"Ag iarraidh…",downloaded:"Íoslódáilte",error:"Earráid",failed:"Theip air.",ariaDownload:"Íoslódáil",titleQuick:"Íoslódáil tapa",comments:"trácht",edited:"Eagraithe"},kk:{download:"Жүктеп алу",downloading:"Жүктелуде…",trying:"Әрекет…",downloaded:"Аяқталды",error:"Қате",failed:"Сәтсіз.",ariaDownload:"Жүктеп алу",titleQuick:"Жылдам жүктеу",comments:"пікір",edited:"Өзгертілді"},km:{download:"ទាញយក",downloading:"កំពុងទាញយក…",trying:"កំពុងព្យាយាម…",downloaded:"បានបញ្ចប់",error:"កំហុស",failed:"បរាជ័យ",ariaDownload:"ទាញយក",titleQuick:"ទាញយកលឿន",comments:"មតិ",edited:"បានកែសម្រួល"},lo:{download:"ດາວໂຫລດ",downloading:"ກຳລັງດາວໂຫລດ…",trying:"ກຳລັງພະຍາຍາມ…",downloaded:"ສຳເລັດ",error:"ຜິດພາດ",failed:"ລົ້ມເຫລວ",ariaDownload:"ດາວໂຫລດ",titleQuick:"ດາວໂຫລດດ່ວນ",comments:"ຄຳເຫັນ",edited:"ແກ້ໄຂແລ້ວ"},mk:{download:"Преземи",downloading:"Преземање…",trying:"Се обидувам…",downloaded:"Готово",error:"Грешка",failed:"Неуспешно.",ariaDownload:"Преземи",titleQuick:"Брзо преземање",comments:"коментари",edited:"Изменето"},mn:{download:"Татах",downloading:"Татаж байна…",trying:"Орлдож байна…",downloaded:"Татсан",error:"Алдаа",failed:"Амжилтгүй.",ariaDownload:"Татах",titleQuick:"Хурдан татах",comments:"сэтгэгдэл",edited:"Зассан"},ne:{download:"डाउनलोड",downloading:"डाउनलोड हुँदै…",trying:"प्रयास गर्दै…",downloaded:"पूरा भयो",error:"त्रुटि",failed:"असफल भयो",ariaDownload:"डाउनलोड",titleQuick:"छिटो डाउनलोड",comments:"टिप्पणीहरू",edited:"सम्पादित"},or:{download:"ଡାଉନଲୋଡ୍",downloading:"ଡାଉନଲୋଡ୍ ହେଉଛି…",trying:"ଚେଷ୍ଟା କରୁଛି…",downloaded:"ସମ୍ପୂର୍ଣ୍ଣ",error:"ତ୍ରୁଟି",failed:"ବିଫଳ ହେଲା",ariaDownload:"ଡାଉନଲୋଡ୍",titleQuick:"ଶୀଘ୍ର ଡାଉନଲୋଡ୍",comments:"ମନ୍ତବ୍ୟ",edited:"ସମ୍ପାଦିତ"},si:{download:"බාගන්න",downloading:"බාගත වෙමින්…",trying:"උත්සාහ කරමින්…",downloaded:"අවසන්",error:"දෝෂයකි",failed:"අසාර්ථකයි",ariaDownload:"බාගන්න",titleQuick:"ඉක්මන් බාගත කිරීම",comments:"අදහස්",edited:"සංස්කරණය"},sw:{download:"Pakua",downloading:"Inapakua…",trying:"Inajaribu…",downloaded:"Imekamilika",error:"Hitilafu",failed:"Imeshindwa.",ariaDownload:"Pakua",titleQuick:"Pakua haraka",comments:"maoni",edited:"Imehaririwa"},uz:{download:"Yuklash",downloading:"Yuklanmoqda…",trying:"Urinilmoqda…",downloaded:"Tayyor",error:"Xato",failed:"Muvaffaqiyatsiz.",ariaDownload:"Yuklash",titleQuick:"Tez yuklash",comments:"sharhlar",edited:"Tahrirlangan"},cy:{download:"Lawrlwytho",downloading:"Yn lawrlwytho…",trying:"Yn ceisio…",downloaded:"Wedi gorffen",error:"Gwall",failed:"Methodd.",ariaDownload:"Lawrlwytho",titleQuick:"Lawrlwytho cyflym",comments:"sylwadau",edited:"Golygwyd"},zu:{download:"Landa",downloading:"Iyalandwa…",trying:"Iyazama…",downloaded:"Ilandīwe",error:"Iphutha",failed:"Ihlulekile.",ariaDownload:"Landa",titleQuick:"Ukulanda okusheshayo",comments:"amazwana",edited:"Kuhleliwe"},sq:{download:"Shkarko",downloading:"Duke shkarkuar…",trying:"Duke provuar…",downloaded:"Përfundoi",error:"Gabim",failed:"Dështoi.",ariaDownload:"Shkarko",titleQuick:"Shkarkim i shpejtë",comments:"komente",edited:"E redaktuar"}};function u(e){try{if(!e||typeof e!="string")return"...";let t="en";typeof document<"u"&&document.documentElement&&document.documentElement.lang?t=document.documentElement.lang:typeof navigator<"u"&&navigator.language&&(t=navigator.language);const o=t.toLowerCase().split(";")[0].trim().replace("_","-"),n=o.split("-")[0];return c[o]&&typeof c[o][e]=="string"?c[o][e]:c[n]&&typeof c[n][e]=="string"?c[n][e]:c.en&&typeof c.en[e]=="string"?c.en[e]:e}catch{try{return c.en[e]||e}catch{return String(e||"Download")}}}function V(){if(typeof document>"u")return!1;const e=document.documentElement.getAttribute("data-darkreader-scheme");if(e==="dark")return!0;if(e==="light")return!1;const t=["dark","dark-theme","theme-dark","night","gm3-dark-theme"],o=(document.documentElement.className||"").toLowerCase(),n=(document.body.className||"").toLowerCase();if(t.some(s=>o.includes(s)||n.includes(s)))return!0;const a=document.querySelector("div[data-stream-item-id]")||document.querySelector('[role="main"]')||document.body,d=_(a);return $(d)<105}function _(e){let t=e;const o=d=>!d||d==="transparent"||d==="rgba(0, 0, 0, 0)";for(;t;){const i=window.getComputedStyle(t).backgroundColor;if(!o(i))return i;t=t.parentElement}const a=window.getComputedStyle(document.documentElement).backgroundColor;return o(a)?"rgb(255, 255, 255)":a}function $(e){const t=e.match(/(\d+),\s*(\d+),\s*(\d+)/);if(!t)return 255;const o=parseInt(t[1],10),n=parseInt(t[2],10),a=parseInt(t[3],10);return Math.sqrt(.299*(o*o)+.587*(n*n)+.114*(a*a))}const Z="cqdEnabled";function ee(e,t){if(typeof chrome>"u"||!chrome.storage?.local){try{e()}catch{}return}try{chrome.storage.local.get({[Z]:!0},o=>{if(chrome.runtime?.lastError){try{e()}catch{}return}if(o[Z]!==!1)try{e()}catch{}})}catch{try{e()}catch{}}}const A=".cqd-download-btn",B="div[data-stream-item-id]",oe="data-cqd-injected",te=3e3,ne=2,G=new WeakMap,f=new WeakMap,y=new WeakMap,E=new Set;let M=!1;const ae={matches:["https://classroom.google.com/*"],runAt:"document_idle",main(){ee(()=>{W(),pe(),C(document),window.addEventListener("scroll",x,{passive:!0});const e=new MutationObserver(t=>{for(const o of t)if(o.type==="childList")o.addedNodes.forEach(n=>{n instanceof HTMLElement&&C(n)}),o.removedNodes.forEach(n=>{n instanceof HTMLElement&&ie(n)});else if(o.type==="attributes"){const n=o.target;if(n instanceof HTMLButtonElement&&n.classList.contains("cqd-download-btn")){const a=de(n);a&&k(a)}}x()});document.body&&e.observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","data-cqd-all-done"]}),window.setInterval(()=>{C(document),x()},4e3)})}};function C(e){e instanceof HTMLButtonElement&&e.classList.contains("cqd-download-btn")&&T(e),e.querySelectorAll(A).forEach(o=>T(o))}function T(e){if(!e.isConnected||f.has(e)&&y.has(e))return;const t=re(e);if(!t)return;let o=G.get(t);o||(o={root:t,files:new Map,downloadAllBtn:null,activated:!1,isBusy:!1},G.set(t,o));const n=le(e);let a=o.files.get(n);a||(a={key:n,buttons:new Set,downloaded:!1,failed:!1,inProgress:!1},o.files.set(n,a)),a.buttons.add(e),f.set(e,o),y.set(e,a),k(o)}function de(e){let t=f.get(e);return t||(T(e),t=f.get(e)||null),t}function ie(e){(e.matches(A)?[e]:Array.from(e.querySelectorAll(A))).forEach(o=>{const n=f.get(o),a=y.get(o);!n||!a||(a.buttons.delete(o),f.delete(o),y.delete(o),a.buttons.size===0&&n.files.delete(a.key),k(n))})}function re(e){const t=e.closest(B);if(t)return t;let o=e.parentElement;for(;o&&o!==document.body&&o!==document.documentElement;){if(o.querySelector(".N5dSp"))return o;o=o.parentElement}const n=e.closest("main")||e.closest('div[role="main"]');return n||null}function le(e){const t=e.dataset,o=t.cqdUrl||"";if(o){const n=o.match(/\/d\/([a-zA-Z0-9_-]+)/)||o.match(/[?&](?:id|resourceId|fileId)=([a-zA-Z0-9_-]+)/);if(n&&n[1])return`drive-id-${n[1]}`;try{const a=new URL(o);return a.searchParams.delete("authuser"),a.searchParams.delete("u"),a.searchParams.delete("hl"),a.toString()}catch{return o}}return t.cqdName?`${t.cqdName}::${t.cqdExt||""}`:`btn-${Math.random().toString(36).slice(2)}`}function N(e){if(e.buttons.size===0)return null;let t=null,o=null;for(const n of e.buttons){if(!n.isConnected||(o||(o=n),!n.offsetParent))continue;if(!t){t=n;continue}t.compareDocumentPosition(n)&Node.DOCUMENT_POSITION_FOLLOWING&&(t=n)}return t||o}function se(e){if(e.buttons.size<=1)return;const t=N(e);if(t)for(const o of e.buttons)o.isConnected&&(o===t?(o.style.removeProperty("display"),o.style.removeProperty("visibility"),o.style.removeProperty("pointer-events")):(o.style.setProperty("display","none","important"),o.style.setProperty("pointer-events","none","important")))}function k(e){E.add(e)}function x(){M||(M=!0,requestAnimationFrame(()=>{M=!1,E.forEach(ce),E.clear()}))}function ce(e){e.downloadAllBtn&&!e.downloadAllBtn.isConnected&&(e.downloadAllBtn=null,e.activated=!1);for(const[l,m]of Array.from(e.files.entries())){for(const b of Array.from(m.buttons))b.isConnected||(m.buttons.delete(b),f.delete(b),y.delete(b));if(m.buttons.size===0){e.files.delete(l);continue}se(m)}const t=e.files.size;if(t<ne){e.downloadAllBtn&&e.downloadAllBtn.isConnected&&e.downloadAllBtn.remove(),e.downloadAllBtn=null,e.activated=!1,e.isBusy=!1,e.resetTimeoutId!=null&&(window.clearTimeout(e.resetTimeoutId),e.resetTimeoutId=void 0);return}const o=me(e),n=o.querySelector(".cqd-download-all-main"),a=o.querySelector(".cqd-download-all-sub");if(!n||!a)return;if(!e.activated){e.isBusy=!1,o.disabled=!1,o.classList.remove("cqd-all-success","cqd-all-error"),n.textContent=u("downloadAll")||"Download all";const l=t===1?"file":"files";a.textContent=`${t} ${l}`,O(o,0);return}let d=0,i=0,s=0;for(const l of e.files.values()){let m=l.downloaded,b=l.failed,j=l.inProgress;for(const L of l.buttons){if(!L.isConnected)continue;const I=L.classList,qe=L.dataset,De=I.contains("cqd-loading")||I.contains("cqd-trying"),ve=I.contains("cqd-success")||qe.cqdAllDone==="true",Se=I.contains("cqd-error");De&&(j=!0),ve&&(m=!0),Se&&(b=!0)}l.downloaded=m,l.inProgress=j,l.failed=!l.downloaded&&b,l.downloaded?d++:l.inProgress?s++:l.failed&&i++}e.isBusy=s>0,e.isBusy&&e.resetTimeoutId!=null&&(window.clearTimeout(e.resetTimeoutId),e.resetTimeoutId=void 0);const r=d===t&&i===0&&t>0,h=d+i===t&&s===0&&t>0;o.disabled=!0;let g,w,p=t>0?d/t:0;r?(g=u("downloaded")||"Downloaded",w=`${d} / ${t}`,o.classList.add("cqd-all-success"),p=1,J(e)):h&&i>0?(d===0?(g=u("error")||"Error",w=`${i} failed`,o.classList.add("cqd-all-error"),p=0):(g=u("downloaded")||"Downloaded",w=`${d} ok, ${i} failed`,o.classList.add("cqd-all-success")),J(e)):(g=u("downloading")||"Downloading…",i===0?w=`${d} → ${t}`:w=`${d} → ${t} (${i} failed)`),n.textContent=g,a.textContent=w,O(o,p)}function J(e){e.resetTimeoutId==null&&(e.resetTimeoutId=window.setTimeout(()=>{e.resetTimeoutId=void 0,e.activated=!1,e.isBusy=!1,e.currentRunId=void 0;try{delete e.root.dataset.cqdGroupActive}catch{}for(const t of e.files.values())t.downloaded=!1,t.failed=!1,t.inProgress=!1;k(e),x()},te))}function we(e){const t=e.querySelector(".N5dSp");if(t)return t;const o=e.querySelector(".JZicYb.gmNu1d")||e.querySelector(".JZicYb");if(o)return o;let n=e;for(;n&&n!==document.body&&n!==document.documentElement;){const a=n.parentElement;if(!a)break;const d=Array.from(a.querySelectorAll(".N5dSp, .JZicYb.gmNu1d, .N5dSp, .JZicYb"));let i=null;for(const s of d){const r=s.compareDocumentPosition(n),h=!!(r&Node.DOCUMENT_POSITION_FOLLOWING);r&Node.DOCUMENT_POSITION_DISCONNECTED||!h||(i?i.compareDocumentPosition(s)&Node.DOCUMENT_POSITION_FOLLOWING&&(i=s):i=s)}if(i)return i;n=a}return null}function me(e){const t=e.downloadAllBtn;if(t&&t.isConnected)return t;const o=e.root,n=we(o),a=o.matches(B),d=!!n&&n.classList.contains("N5dSp"),i=n||o,s=!!n;i.style.setProperty("flex-wrap","wrap","important"),i.style.setProperty("align-items","center","important"),i.classList.contains("N5dSp")&&(i.style.display="flex");const r=document.createElement("button");r.type="button",r.className="cqd-download-all-btn",s&&r.classList.add("cqd-in-header"),r.setAttribute(oe,"true"),V()&&r.classList.add("cqd-theme-dark"),r.setAttribute("aria-label",u("downloadAll")||"Download all attachments in this post"),r.title=u("downloadAll")||"Download all";const h=document.createElement("span");h.className="cqd-icon-wrapper cqd-download-all-icon-wrapper";const g=document.createElement("span");g.className="cqd-download-all-icon",h.appendChild(g);const w=document.createElement("span");w.className="cqd-download-all-main";const p=document.createElement("span");return p.className="cqd-download-all-sub",r.appendChild(h),r.appendChild(w),r.appendChild(p),window.getComputedStyle(i).position==="static"&&(i.style.position="relative"),r.addEventListener("click",m=>{m.preventDefault(),m.stopPropagation(),fe(e)}),d&&n?ge(r,n):a?ue(r,n||o):(i.appendChild(r),r.style.marginInlineStart="8px"),e.downloadAllBtn=r,r}function ge(e,t){const o=t,n=H(o);if(n&&n!==e){const a=n.parentElement;if(a){let d=a.querySelector('[data-cqd-right-wrapper="1"]');const i=window.getComputedStyle(n);(!d||!d.contains(n))&&(d=document.createElement("span"),d.dataset.cqdRightWrapper="1",d.style.display="inline-flex",d.style.alignItems="center",d.style.gap="8px",i.marginLeft==="auto"&&(n.style.marginLeft="0",d.style.marginLeft="auto"),a.insertBefore(d,n),d.appendChild(n)),d.insertBefore(e,d.firstChild),e.style.marginInlineEnd="4px";return}}o.appendChild(e),e.style.marginInlineStart="8px"}function ue(e,t){const o=H(t);o&&o!==e&&o.parentNode===t?(t.insertBefore(e,o),e.style.marginInlineEnd="8px",e.style.marginInlineStart="8px"):(t.appendChild(e),e.style.marginInlineStart="8px")}function H(e){const t=e.querySelector('[data-guided-help-id="streamItemActionMenuGH"]');if(t)return t;const o=[".pYTkkf-Bz112c-LgbsSe",'div[role="button"][aria-haspopup="true"]','div[role="button"][aria-haspopup="menu"]','button[aria-haspopup="menu"]'];for(const n of o){const a=e.querySelector(n);if(a)return a}return null}function fe(e){if(e.isBusy||e.activated)return;e.activated=!0,e.isBusy=!0,e.currentRunId=Date.now();try{e.root.dataset.cqdGroupActive="1"}catch{}for(const o of e.files.values())o.downloaded=!1,o.failed=!1,o.inProgress=!1;e.resetTimeoutId!=null&&(window.clearTimeout(e.resetTimeoutId),e.resetTimeoutId=void 0);const t=e.downloadAllBtn;t&&(t.disabled=!0);for(const o of e.files.values()){const n=N(o);if(!n)continue;const a=he(n);(a==="idle"||a==="error")&&n.click()}k(e),x()}function he(e){const t=e.classList;return t.contains("cqd-loading")?"loading":t.contains("cqd-trying")?"trying":t.contains("cqd-success")?"success":t.contains("cqd-error")?"error":e.dataset.cqdAllDone==="true"?"success":"idle"}function O(e,t){const o=Math.max(0,Math.min(1,t)),n=Math.round(o*100);e.style.setProperty("--cqd-progress",`${n}%`)}function pe(){try{const e=be();document.body.setAttribute("data-cqd-dir",e)}catch{}}function be(){return(document.documentElement.dir||document.body.dir)==="rtl"||window.getComputedStyle(document.body).direction==="rtl"?"rtl":"ltr"}const z=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function D(e,...t){}const ye={debug:(...e)=>D(console.debug,...e),log:(...e)=>D(console.log,...e),warn:(...e)=>D(console.warn,...e),error:(...e)=>D(console.error,...e)};class Q extends Event{constructor(t,o){super(Q.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=o}static EVENT_NAME=F("wxt:locationchange")}function F(e){return`${z?.runtime?.id}:download_all:${e}`}function ke(e){let t,o;return{run(){t==null&&(o=new URL(location.href),t=e.setInterval(()=>{let n=new URL(location.href);n.href!==o.href&&(window.dispatchEvent(new Q(n,o)),o=n)},1e3))}}}class v{constructor(t,o){this.contentScriptName=t,this.options=o,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=F("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=ke(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return z.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,o){const n=setInterval(()=>{this.isValid&&t()},o);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(t,o){const n=setTimeout(()=>{this.isValid&&t()},o);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(t){const o=requestAnimationFrame((...n)=>{this.isValid&&t(...n)});return this.onInvalidated(()=>cancelAnimationFrame(o)),o}requestIdleCallback(t,o){const n=requestIdleCallback((...a)=>{this.signal.aborted||t(...a)},o);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(t,o,n,a){o==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(o.startsWith("wxt:")?F(o):o,n,{...a,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),ye.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:v.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){const o=t.data?.type===v.SCRIPT_STARTED_MESSAGE_TYPE,n=t.data?.contentScriptName===this.contentScriptName,a=!this.receivedMessageIds.has(t.data?.messageId);return o&&n&&a}listenForNewerScripts(t){let o=!0;const n=a=>{if(this.verifyScriptStartedEvent(a)){this.receivedMessageIds.add(a.data.messageId);const d=o;if(o=!1,d&&t?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}}function Me(){}function S(e,...t){}const xe={debug:(...e)=>S(console.debug,...e),log:(...e)=>S(console.log,...e),warn:(...e)=>S(console.warn,...e),error:(...e)=>S(console.error,...e)};return(async()=>{try{const{main:e,...t}=ae,o=new v("download_all",t);return await e(o)}catch(e){throw xe.error('The content script "download_all" crashed on startup!',e),e}})()})();
downloadall;